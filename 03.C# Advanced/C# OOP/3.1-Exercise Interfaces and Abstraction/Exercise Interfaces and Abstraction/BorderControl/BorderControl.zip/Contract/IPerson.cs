﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public interface IPerson
    {
        
        public string Id { get; set; }

    }
}
